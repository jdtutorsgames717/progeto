const express = require('express');
const { query } = require('../config/database');
const router = express.Router();

// Middleware de autenticação (copiado do auth.js)
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, message: 'Token de acesso requerido' });
  }

  const jwt = require('jsonwebtoken');
  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ success: false, message: 'Token inválido' });
    }
    req.user = user;
    next();
  });
};

// Aplicar middleware de autenticação
router.use(authenticateToken);

// Listar todos os canais
router.get('/canais', async (req, res) => {
  try {
    const canais = await query(
      'SELECT * FROM canais ORDER BY nome ASC'
    );

    res.json({
      success: true,
      data: canais
    });

  } catch (error) {
    console.error('Erro ao listar canais:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao carregar canais'
    });
  }
});

// Criar novo canal
router.post('/canais', async (req, res) => {
  try {
    const {
      nome,
      tipo,
      url,
      api_endpoint,
      api_key,
      comissao,
      configuracoes
    } = req.body;

    if (!nome || !tipo) {
      return res.status(400).json({
        success: false,
        message: 'Nome e tipo são obrigatórios'
      });
    }

    const novoCanal = await query(
      `INSERT INTO canais 
       (nome, tipo, url, api_endpoint, api_key, comissao, configuracoes)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        nome, tipo, url, api_endpoint, api_key,
        comissao || 0, JSON.stringify(configuracoes || {})
      ]
    );

    res.status(201).json({
      success: true,
      message: 'Canal criado com sucesso',
      data: { id: novoCanal.insertId }
    });

  } catch (error) {
    console.error('Erro ao criar canal:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao criar canal'
    });
  }
});

// Atualizar canal
router.put('/canais/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const {
      nome,
      tipo,
      url,
      api_endpoint,
      api_key,
      comissao,
      ativo,
      configuracoes
    } = req.body;

    await query(
      `UPDATE canais SET 
       nome = COALESCE(?, nome),
       tipo = COALESCE(?, tipo),
       url = COALESCE(?, url),
       api_endpoint = COALESCE(?, api_endpoint),
       api_key = COALESCE(?, api_key),
       comissao = COALESCE(?, comissao),
       ativo = COALESCE(?, ativo),
       configuracoes = COALESCE(?, configuracoes)
       WHERE id = ?`,
      [
        nome, tipo, url, api_endpoint, api_key, comissao, ativo,
        configuracoes ? JSON.stringify(configuracoes) : null, id
      ]
    );

    res.json({
      success: true,
      message: 'Canal atualizado com sucesso'
    });

  } catch (error) {
    console.error('Erro ao atualizar canal:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao atualizar canal'
    });
  }
});

// Obter inventário por canal
router.get('/inventario', async (req, res) => {
  try {
    const {
      propriedade_id,
      canal_id,
      data_inicio,
      data_fim,
      tipo_quarto_id
    } = req.query;

    let whereClause = 'WHERE 1=1';
    let params = [];

    if (propriedade_id) {
      whereClause += ' AND ic.propriedade_id = ?';
      params.push(propriedade_id);
    }

    if (canal_id) {
      whereClause += ' AND ic.canal_id = ?';
      params.push(canal_id);
    }

    if (tipo_quarto_id) {
      whereClause += ' AND ic.tipo_quarto_id = ?';
      params.push(tipo_quarto_id);
    }

    if (data_inicio) {
      whereClause += ' AND ic.data_disponibilidade >= ?';
      params.push(data_inicio);
    }

    if (data_fim) {
      whereClause += ' AND ic.data_disponibilidade <= ?';
      params.push(data_fim);
    }

    const inventario = await query(
      `SELECT ic.*, c.nome as canal_nome, tq.nome as tipo_quarto_nome,
              p.nome as propriedade_nome
       FROM inventario_canais ic
       JOIN canais c ON ic.canal_id = c.id
       JOIN tipos_quartos tq ON ic.tipo_quarto_id = tq.id
       JOIN propriedades p ON ic.propriedade_id = p.id
       ${whereClause}
       ORDER BY ic.data_disponibilidade ASC`,
      params
    );

    res.json({
      success: true,
      data: inventario
    });

  } catch (error) {
    console.error('Erro ao obter inventário:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao carregar inventário'
    });
  }
});

// Atualizar inventário
router.post('/inventario', async (req, res) => {
  try {
    const {
      propriedade_id,
      tipo_quarto_id,
      canal_id,
      data_disponibilidade,
      quartos_disponiveis,
      preco,
      restricoes
    } = req.body;

    if (!propriedade_id || !tipo_quarto_id || !canal_id || !data_disponibilidade || !preco) {
      return res.status(400).json({
        success: false,
        message: 'Campos obrigatórios não preenchidos'
      });
    }

    // Verificar se já existe inventário para esta combinação
    const inventarioExistente = await query(
      `SELECT id FROM inventario_canais 
       WHERE propriedade_id = ? AND tipo_quarto_id = ? 
       AND canal_id = ? AND data_disponibilidade = ?`,
      [propriedade_id, tipo_quarto_id, canal_id, data_disponibilidade]
    );

    if (inventarioExistente.length > 0) {
      // Atualizar existente
      await query(
        `UPDATE inventario_canais SET 
         quartos_disponiveis = ?, preco = ?, restricoes = ?
         WHERE id = ?`,
        [
          quartos_disponiveis || 0,
          preco,
          JSON.stringify(restricoes || {}),
          inventarioExistente[0].id
        ]
      );
    } else {
      // Criar novo
      await query(
        `INSERT INTO inventario_canais 
         (propriedade_id, tipo_quarto_id, canal_id, data_disponibilidade,
          quartos_disponiveis, preco, restricoes)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          propriedade_id, tipo_quarto_id, canal_id, data_disponibilidade,
          quartos_disponiveis || 0, preco, JSON.stringify(restricoes || {})
        ]
      );
    }

    res.json({
      success: true,
      message: 'Inventário atualizado com sucesso'
    });

  } catch (error) {
    console.error('Erro ao atualizar inventário:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao atualizar inventário'
    });
  }
});

// Sincronizar inventário em lote
router.post('/inventario/sincronizar', async (req, res) => {
  try {
    const {
      propriedade_id,
      tipo_quarto_id,
      data_inicio,
      data_fim,
      canais,
      preco_base,
      quartos_disponiveis
    } = req.body;

    if (!propriedade_id || !tipo_quarto_id || !data_inicio || !data_fim || !canais || !preco_base) {
      return res.status(400).json({
        success: false,
        message: 'Campos obrigatórios não preenchidos'
      });
    }

    const dataInicio = new Date(data_inicio);
    const dataFim = new Date(data_fim);
    const diasParaSincronizar = [];

    // Gerar lista de datas
    for (let data = new Date(dataInicio); data <= dataFim; data.setDate(data.getDate() + 1)) {
      diasParaSincronizar.push(new Date(data).toISOString().split('T')[0]);
    }

    // Sincronizar para cada canal e data
    for (const canal of canais) {
      for (const data of diasParaSincronizar) {
        // Calcular preço com base na comissão do canal
        const canalInfo = await query('SELECT comissao FROM canais WHERE id = ?', [canal.id]);
        const comissao = canalInfo[0]?.comissao || 0;
        const precoFinal = canal.preco_customizado || (preco_base * (1 + comissao / 100));

        // Verificar se já existe
        const existente = await query(
          `SELECT id FROM inventario_canais 
           WHERE propriedade_id = ? AND tipo_quarto_id = ? 
           AND canal_id = ? AND data_disponibilidade = ?`,
          [propriedade_id, tipo_quarto_id, canal.id, data]
        );

        if (existente.length > 0) {
          await query(
            `UPDATE inventario_canais SET 
             quartos_disponiveis = ?, preco = ?
             WHERE id = ?`,
            [quartos_disponiveis || 0, precoFinal, existente[0].id]
          );
        } else {
          await query(
            `INSERT INTO inventario_canais 
             (propriedade_id, tipo_quarto_id, canal_id, data_disponibilidade,
              quartos_disponiveis, preco)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [propriedade_id, tipo_quarto_id, canal.id, data, quartos_disponiveis || 0, precoFinal]
          );
        }
      }
    }

    res.json({
      success: true,
      message: `Inventário sincronizado para ${diasParaSincronizar.length} dias em ${canais.length} canais`
    });

  } catch (error) {
    console.error('Erro ao sincronizar inventário:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao sincronizar inventário'
    });
  }
});

// Obter relatório de performance por canal
router.get('/relatorio/performance', async (req, res) => {
  try {
    const { data_inicio, data_fim, propriedade_id } = req.query;

    let whereClause = 'WHERE r.status != "cancelada"';
    let params = [];

    if (data_inicio) {
      whereClause += ' AND r.created_at >= ?';
      params.push(data_inicio);
    }

    if (data_fim) {
      whereClause += ' AND r.created_at <= ?';
      params.push(data_fim);
    }

    if (propriedade_id) {
      whereClause += ' AND r.propriedade_id = ?';
      params.push(propriedade_id);
    }

    const performance = await query(
      `SELECT 
         r.origem,
         COUNT(*) as total_reservas,
         SUM(r.valor_total) as receita_total,
         SUM(r.valor_pago) as receita_paga,
         AVG(r.valor_total) as ticket_medio,
         AVG(DATEDIFF(r.data_checkout, r.data_checkin)) as estadia_media
       FROM reservas r
       ${whereClause}
       GROUP BY r.origem
       ORDER BY receita_total DESC`,
      params
    );

    // Calcular comissões por canal
    const performanceComComissao = await Promise.all(
      performance.map(async (item) => {
        if (item.origem !== 'direto') {
          const canal = await query(
            'SELECT comissao FROM canais WHERE nome LIKE ?',
            [`%${item.origem}%`]
          );
          const comissao = canal[0]?.comissao || 0;
          const valorComissao = (item.receita_total * comissao) / 100;
          
          return {
            ...item,
            comissao_percentual: comissao,
            valor_comissao: valorComissao,
            receita_liquida: item.receita_total - valorComissao
          };
        }
        return {
          ...item,
          comissao_percentual: 0,
          valor_comissao: 0,
          receita_liquida: item.receita_total
        };
      })
    );

    res.json({
      success: true,
      data: performanceComComissao
    });

  } catch (error) {
    console.error('Erro ao gerar relatório de performance:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao gerar relatório de performance'
    });
  }
});

// Obter disponibilidade consolidada
router.get('/disponibilidade', async (req, res) => {
  try {
    const {
      propriedade_id,
      tipo_quarto_id,
      data_inicio,
      data_fim
    } = req.query;

    if (!propriedade_id || !data_inicio || !data_fim) {
      return res.status(400).json({
        success: false,
        message: 'Propriedade, data de início e fim são obrigatórias'
      });
    }

    let whereClause = 'WHERE ic.propriedade_id = ?';
    let params = [propriedade_id];

    if (tipo_quarto_id) {
      whereClause += ' AND ic.tipo_quarto_id = ?';
      params.push(tipo_quarto_id);
    }

    whereClause += ' AND ic.data_disponibilidade BETWEEN ? AND ?';
    params.push(data_inicio, data_fim);

    const disponibilidade = await query(
      `SELECT 
         ic.data_disponibilidade,
         tq.nome as tipo_quarto,
         c.nome as canal,
         ic.quartos_disponiveis,
         ic.preco,
         ic.restricoes
       FROM inventario_canais ic
       JOIN tipos_quartos tq ON ic.tipo_quarto_id = tq.id
       JOIN canais c ON ic.canal_id = c.id
       ${whereClause}
       ORDER BY ic.data_disponibilidade, tq.nome, c.nome`,
      params
    );

    // Agrupar por data e tipo de quarto
    const disponibilidadeAgrupada = disponibilidade.reduce((acc, item) => {
      const chave = `${item.data_disponibilidade}_${item.tipo_quarto}`;
      if (!acc[chave]) {
        acc[chave] = {
          data: item.data_disponibilidade,
          tipo_quarto: item.tipo_quarto,
          canais: []
        };
      }
      acc[chave].canais.push({
        canal: item.canal,
        quartos_disponiveis: item.quartos_disponiveis,
        preco: parseFloat(item.preco),
        restricoes: item.restricoes ? JSON.parse(item.restricoes) : {}
      });
      return acc;
    }, {});

    res.json({
      success: true,
      data: Object.values(disponibilidadeAgrupada)
    });

  } catch (error) {
    console.error('Erro ao obter disponibilidade:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao carregar disponibilidade'
    });
  }
});

module.exports = router;