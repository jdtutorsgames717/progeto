const express = require('express');
const { query } = require('../config/database');
const router = express.Router();

// Middleware de autenticação (copiado do auth.js)
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, message: 'Token de acesso requerido' });
  }

  const jwt = require('jsonwebtoken');
  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ success: false, message: 'Token inválido' });
    }
    req.user = user;
    next();
  });
};

// Aplicar middleware de autenticação
router.use(authenticateToken);

// === PROPRIEDADES ===

// Listar propriedades
router.get('/propriedades', async (req, res) => {
  try {
    const propriedades = await query(
      'SELECT * FROM propriedades WHERE ativo = TRUE ORDER BY nome ASC'
    );

    res.json({
      success: true,
      data: propriedades
    });

  } catch (error) {
    console.error('Erro ao listar propriedades:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao carregar propriedades'
    });
  }
});

// Criar propriedade
router.post('/propriedades', async (req, res) => {
  try {
    const {
      nome, descricao, endereco, cidade, estado, cep,
      telefone, email, website, checkin_time, checkout_time
    } = req.body;

    if (!nome) {
      return res.status(400).json({
        success: false,
        message: 'Nome da propriedade é obrigatório'
      });
    }

    const novaPropriedade = await query(
      `INSERT INTO propriedades 
       (nome, descricao, endereco, cidade, estado, cep, telefone, email, website, checkin_time, checkout_time)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [nome, descricao, endereco, cidade, estado, cep, telefone, email, website, checkin_time, checkout_time]
    );

    res.status(201).json({
      success: true,
      message: 'Propriedade criada com sucesso',
      data: { id: novaPropriedade.insertId }
    });

  } catch (error) {
    console.error('Erro ao criar propriedade:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao criar propriedade'
    });
  }
});

// === TIPOS DE QUARTOS ===

// Listar tipos de quartos
router.get('/tipos-quartos', async (req, res) => {
  try {
    const { propriedade_id } = req.query;
    
    let whereClause = 'WHERE tq.ativo = TRUE';
    let params = [];
    
    if (propriedade_id) {
      whereClause += ' AND tq.propriedade_id = ?';
      params.push(propriedade_id);
    }

    const tiposQuartos = await query(
      `SELECT tq.*, p.nome as propriedade_nome
       FROM tipos_quartos tq
       JOIN propriedades p ON tq.propriedade_id = p.id
       ${whereClause}
       ORDER BY p.nome, tq.nome`,
      params
    );

    res.json({
      success: true,
      data: tiposQuartos
    });

  } catch (error) {
    console.error('Erro ao listar tipos de quartos:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao carregar tipos de quartos'
    });
  }
});

// Criar tipo de quarto
router.post('/tipos-quartos', async (req, res) => {
  try {
    const {
      propriedade_id, nome, descricao, capacidade_adultos,
      capacidade_criancas, preco_base, area, comodidades
    } = req.body;

    if (!propriedade_id || !nome || !preco_base) {
      return res.status(400).json({
        success: false,
        message: 'Propriedade, nome e preço base são obrigatórios'
      });
    }

    const novoTipo = await query(
      `INSERT INTO tipos_quartos 
       (propriedade_id, nome, descricao, capacidade_adultos, capacidade_criancas, preco_base, area, comodidades)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        propriedade_id, nome, descricao, capacidade_adultos || 2,
        capacidade_criancas || 0, preco_base, area,
        JSON.stringify(comodidades || [])
      ]
    );

    res.status(201).json({
      success: true,
      message: 'Tipo de quarto criado com sucesso',
      data: { id: novoTipo.insertId }
    });

  } catch (error) {
    console.error('Erro ao criar tipo de quarto:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao criar tipo de quarto'
    });
  }
});

// === QUARTOS ===

// Listar quartos
router.get('/quartos', async (req, res) => {
  try {
    const { propriedade_id, status, tipo_quarto_id } = req.query;
    
    let whereClause = 'WHERE q.ativo = TRUE';
    let params = [];
    
    if (propriedade_id) {
      whereClause += ' AND q.propriedade_id = ?';
      params.push(propriedade_id);
    }
    
    if (status) {
      whereClause += ' AND q.status = ?';
      params.push(status);
    }
    
    if (tipo_quarto_id) {
      whereClause += ' AND q.tipo_quarto_id = ?';
      params.push(tipo_quarto_id);
    }

    const quartos = await query(
      `SELECT q.*, tq.nome as tipo_nome, tq.preco_base, p.nome as propriedade_nome
       FROM quartos q
       JOIN tipos_quartos tq ON q.tipo_quarto_id = tq.id
       JOIN propriedades p ON q.propriedade_id = p.id
       ${whereClause}
       ORDER BY p.nome, q.numero`,
      params
    );

    res.json({
      success: true,
      data: quartos
    });

  } catch (error) {
    console.error('Erro ao listar quartos:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao carregar quartos'
    });
  }
});

// Criar quarto
router.post('/quartos', async (req, res) => {
  try {
    const {
      propriedade_id, tipo_quarto_id, numero, andar, observacoes
    } = req.body;

    if (!propriedade_id || !tipo_quarto_id || !numero) {
      return res.status(400).json({
        success: false,
        message: 'Propriedade, tipo de quarto e número são obrigatórios'
      });
    }

    // Verificar se número já existe na propriedade
    const quartoExistente = await query(
      'SELECT id FROM quartos WHERE propriedade_id = ? AND numero = ?',
      [propriedade_id, numero]
    );

    if (quartoExistente.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Já existe um quarto com este número nesta propriedade'
      });
    }

    const novoQuarto = await query(
      `INSERT INTO quartos 
       (propriedade_id, tipo_quarto_id, numero, andar, observacoes)
       VALUES (?, ?, ?, ?, ?)`,
      [propriedade_id, tipo_quarto_id, numero, andar, observacoes]
    );

    res.status(201).json({
      success: true,
      message: 'Quarto criado com sucesso',
      data: { id: novoQuarto.insertId }
    });

  } catch (error) {
    console.error('Erro ao criar quarto:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao criar quarto'
    });
  }
});

// Atualizar status do quarto
router.put('/quartos/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    const { status, observacoes } = req.body;

    if (!status) {
      return res.status(400).json({
        success: false,
        message: 'Status é obrigatório'
      });
    }

    const statusValidos = ['disponivel', 'ocupado', 'manutencao', 'limpeza'];
    if (!statusValidos.includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Status inválido'
      });
    }

    await query(
      'UPDATE quartos SET status = ?, observacoes = COALESCE(?, observacoes) WHERE id = ?',
      [status, observacoes, id]
    );

    res.json({
      success: true,
      message: 'Status do quarto atualizado com sucesso'
    });

  } catch (error) {
    console.error('Erro ao atualizar status do quarto:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao atualizar status do quarto'
    });
  }
});

// === HÓSPEDES ===

// Listar hóspedes
router.get('/hospedes', async (req, res) => {
  try {
    const { search, limit = 50 } = req.query;
    
    let whereClause = 'WHERE 1=1';
    let params = [];
    
    if (search) {
      whereClause += ' AND (nome LIKE ? OR email LIKE ? OR documento LIKE ?)';
      const searchTerm = `%${search}%`;
      params.push(searchTerm, searchTerm, searchTerm);
    }
    
    params.push(parseInt(limit));

    const hospedes = await query(
      `SELECT * FROM hospedes 
       ${whereClause}
       ORDER BY nome ASC
       LIMIT ?`,
      params
    );

    res.json({
      success: true,
      data: hospedes
    });

  } catch (error) {
    console.error('Erro ao listar hóspedes:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao carregar hóspedes'
    });
  }
});

// Obter hóspede por ID
router.get('/hospedes/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const hospedes = await query(
      'SELECT * FROM hospedes WHERE id = ?',
      [id]
    );

    if (hospedes.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Hóspede não encontrado'
      });
    }

    // Buscar histórico de reservas
    const reservas = await query(
      `SELECT r.*, p.nome as propriedade_nome, tq.nome as tipo_quarto
       FROM reservas r
       JOIN propriedades p ON r.propriedade_id = p.id
       JOIN tipos_quartos tq ON r.tipo_quarto_id = tq.id
       WHERE r.hospede_id = ?
       ORDER BY r.created_at DESC`,
      [id]
    );

    res.json({
      success: true,
      data: {
        ...hospedes[0],
        historico_reservas: reservas
      }
    });

  } catch (error) {
    console.error('Erro ao obter hóspede:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao carregar hóspede'
    });
  }
});

// === TARIFAS ===

// Listar tarifas
router.get('/tarifas', async (req, res) => {
  try {
    const { propriedade_id, tipo_quarto_id, ativo } = req.query;
    
    let whereClause = 'WHERE 1=1';
    let params = [];
    
    if (propriedade_id) {
      whereClause += ' AND t.propriedade_id = ?';
      params.push(propriedade_id);
    }
    
    if (tipo_quarto_id) {
      whereClause += ' AND t.tipo_quarto_id = ?';
      params.push(tipo_quarto_id);
    }
    
    if (ativo !== undefined) {
      whereClause += ' AND t.ativo = ?';
      params.push(ativo === 'true');
    }

    const tarifas = await query(
      `SELECT t.*, p.nome as propriedade_nome, tq.nome as tipo_quarto_nome
       FROM tarifas t
       JOIN propriedades p ON t.propriedade_id = p.id
       JOIN tipos_quartos tq ON t.tipo_quarto_id = tq.id
       ${whereClause}
       ORDER BY t.data_inicio DESC`,
      params
    );

    res.json({
      success: true,
      data: tarifas
    });

  } catch (error) {
    console.error('Erro ao listar tarifas:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao carregar tarifas'
    });
  }
});

// Criar tarifa
router.post('/tarifas', async (req, res) => {
  try {
    const {
      propriedade_id, tipo_quarto_id, nome, data_inicio,
      data_fim, preco, tipo
    } = req.body;

    if (!propriedade_id || !tipo_quarto_id || !nome || !data_inicio || !data_fim || !preco) {
      return res.status(400).json({
        success: false,
        message: 'Todos os campos obrigatórios devem ser preenchidos'
      });
    }

    if (new Date(data_inicio) >= new Date(data_fim)) {
      return res.status(400).json({
        success: false,
        message: 'Data de fim deve ser posterior à data de início'
      });
    }

    const novaTarifa = await query(
      `INSERT INTO tarifas 
       (propriedade_id, tipo_quarto_id, nome, data_inicio, data_fim, preco, tipo)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [propriedade_id, tipo_quarto_id, nome, data_inicio, data_fim, preco, tipo || 'especial']
    );

    res.status(201).json({
      success: true,
      message: 'Tarifa criada com sucesso',
      data: { id: novaTarifa.insertId }
    });

  } catch (error) {
    console.error('Erro ao criar tarifa:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao criar tarifa'
    });
  }
});

// === RELATÓRIOS ===

// Relatório de ocupação
router.get('/relatorios/ocupacao', async (req, res) => {
  try {
    const { propriedade_id, data_inicio, data_fim } = req.query;
    
    if (!data_inicio || !data_fim) {
      return res.status(400).json({
        success: false,
        message: 'Data de início e fim são obrigatórias'
      });
    }

    let whereClause = 'WHERE r.status != "cancelada"';
    let params = [data_inicio, data_fim];
    
    if (propriedade_id) {
      whereClause += ' AND r.propriedade_id = ?';
      params.push(propriedade_id);
    }

    const ocupacao = await query(
      `SELECT 
         DATE(r.data_checkin) as data,
         COUNT(*) as reservas_ativas,
         SUM(CASE WHEN r.status = 'checkin' THEN 1 ELSE 0 END) as quartos_ocupados,
         AVG(r.valor_total) as valor_medio
       FROM reservas r
       WHERE r.data_checkin BETWEEN ? AND ?
       ${whereClause.replace('WHERE r.status != "cancelada"', 'AND r.status != "cancelada"')}
       GROUP BY DATE(r.data_checkin)
       ORDER BY data`,
      params
    );

    res.json({
      success: true,
      data: ocupacao
    });

  } catch (error) {
    console.error('Erro ao gerar relatório de ocupação:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao gerar relatório de ocupação'
    });
  }
});

// Relatório financeiro
router.get('/relatorios/financeiro', async (req, res) => {
  try {
    const { propriedade_id, data_inicio, data_fim } = req.query;
    
    if (!data_inicio || !data_fim) {
      return res.status(400).json({
        success: false,
        message: 'Data de início e fim são obrigatórias'
      });
    }

    let whereClause = 'WHERE r.status != "cancelada"';
    let params = [data_inicio, data_fim];
    
    if (propriedade_id) {
      whereClause += ' AND r.propriedade_id = ?';
      params.push(propriedade_id);
    }

    const financeiro = await query(
      `SELECT 
         DATE(r.created_at) as data,
         COUNT(*) as total_reservas,
         SUM(r.valor_total) as receita_bruta,
         SUM(r.valor_total - r.valor_pago) as pendente,
         r.origem,
         AVG(r.valor_total) as ticket_medio
       FROM reservas r
       WHERE r.created_at BETWEEN ? AND ?
       ${whereClause.replace('WHERE r.status != "cancelada"', 'AND r.status != "cancelada"')}
       GROUP BY DATE(r.created_at), r.origem
       ORDER BY data DESC, receita_bruta DESC`,
      params
    );

    res.json({
      success: true,
      data: financeiro
    });

  } catch (error) {
    console.error('Erro ao gerar relatório financeiro:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao gerar relatório financeiro'
    });
  }
});

module.exports = router;