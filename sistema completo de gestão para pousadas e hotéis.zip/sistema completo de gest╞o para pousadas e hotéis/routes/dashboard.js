const express = require('express');
const { query } = require('../config/database');
const router = express.Router();

// Middleware de autenticação (copiado do auth.js)
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, message: 'Token de acesso requerido' });
  }

  const jwt = require('jsonwebtoken');
  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ success: false, message: 'Token inválido' });
    }
    req.user = user;
    next();
  });
};

// Aplicar middleware de autenticação em todas as rotas
router.use(authenticateToken);

// Rota para obter estatísticas do dashboard
router.get('/stats', async (req, res) => {
  try {
    // Estatísticas gerais
    const hoje = new Date().toISOString().split('T')[0];
    const mesAtual = new Date().toISOString().slice(0, 7);
    
    // Total de reservas hoje
    const reservasHoje = await query(
      `SELECT COUNT(*) as total FROM reservas 
       WHERE DATE(created_at) = ? AND status != 'cancelada'`,
      [hoje]
    );

    // Reservas por status
    const reservasPorStatus = await query(
      `SELECT status, COUNT(*) as total FROM reservas 
       WHERE DATE(data_checkin) >= ? AND status != 'cancelada'
       GROUP BY status`,
      [hoje]
    );

    // Check-ins hoje
    const checkinsHoje = await query(
      `SELECT COUNT(*) as total FROM reservas 
       WHERE DATE(data_checkin) = ? AND status IN ('confirmada', 'checkin')`,
      [hoje]
    );

    // Check-outs hoje
    const checkoutsHoje = await query(
      `SELECT COUNT(*) as total FROM reservas 
       WHERE DATE(data_checkout) = ? AND status = 'checkin'`,
      [hoje]
    );

    // Ocupação atual
    const quartosOcupados = await query(
      `SELECT COUNT(*) as total FROM quartos 
       WHERE status = 'ocupado' AND ativo = TRUE`
    );

    const totalQuartos = await query(
      `SELECT COUNT(*) as total FROM quartos 
       WHERE ativo = TRUE`
    );

    // Receita do mês
    const receitaMes = await query(
      `SELECT COALESCE(SUM(valor_pago), 0) as total FROM reservas 
       WHERE DATE_FORMAT(created_at, '%Y-%m') = ? AND status != 'cancelada'`,
      [mesAtual]
    );

    // Reservas por origem
    const reservasPorOrigem = await query(
      `SELECT origem, COUNT(*) as total FROM reservas 
       WHERE DATE_FORMAT(created_at, '%Y-%m') = ? AND status != 'cancelada'
       GROUP BY origem`
    );

    // Próximas chegadas (próximos 7 dias)
    const proximasChegadas = await query(
      `SELECT r.*, h.nome as hospede_nome, h.telefone, q.numero as quarto_numero
       FROM reservas r
       JOIN hospedes h ON r.hospede_id = h.id
       LEFT JOIN quartos q ON r.quarto_id = q.id
       WHERE r.data_checkin BETWEEN ? AND DATE_ADD(?, INTERVAL 7 DAY)
       AND r.status IN ('confirmada', 'pendente')
       ORDER BY r.data_checkin ASC
       LIMIT 10`,
      [hoje, hoje]
    );

    // Próximas saídas (próximos 7 dias)
    const proximasSaidas = await query(
      `SELECT r.*, h.nome as hospede_nome, h.telefone, q.numero as quarto_numero
       FROM reservas r
       JOIN hospedes h ON r.hospede_id = h.id
       LEFT JOIN quartos q ON r.quarto_id = q.id
       WHERE r.data_checkout BETWEEN ? AND DATE_ADD(?, INTERVAL 7 DAY)
       AND r.status = 'checkin'
       ORDER BY r.data_checkout ASC
       LIMIT 10`,
      [hoje, hoje]
    );

    // Quartos por status
    const quartosPorStatus = await query(
      `SELECT status, COUNT(*) as total FROM quartos 
       WHERE ativo = TRUE
       GROUP BY status`
    );

    const taxaOcupacao = totalQuartos[0].total > 0 
      ? ((quartosOcupados[0].total / totalQuartos[0].total) * 100).toFixed(1)
      : 0;

    res.json({
      success: true,
      data: {
        resumo: {
          reservasHoje: reservasHoje[0].total,
          checkinsHoje: checkinsHoje[0].total,
          checkoutsHoje: checkoutsHoje[0].total,
          quartosOcupados: quartosOcupados[0].total,
          totalQuartos: totalQuartos[0].total,
          taxaOcupacao: parseFloat(taxaOcupacao),
          receitaMes: parseFloat(receitaMes[0].total)
        },
        graficos: {
          reservasPorStatus,
          reservasPorOrigem,
          quartosPorStatus
        },
        proximasChegadas,
        proximasSaidas
      }
    });

  } catch (error) {
    console.error('Erro ao obter estatísticas:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao carregar estatísticas do dashboard'
    });
  }
});

// Rota para obter reservas recentes
router.get('/reservas-recentes', async (req, res) => {
  try {
    const limit = req.query.limit || 10;
    
    const reservas = await query(
      `SELECT r.*, h.nome as hospede_nome, h.email, h.telefone,
              tq.nome as tipo_quarto, q.numero as quarto_numero,
              p.nome as propriedade_nome
       FROM reservas r
       JOIN hospedes h ON r.hospede_id = h.id
       JOIN tipos_quartos tq ON r.tipo_quarto_id = tq.id
       LEFT JOIN quartos q ON r.quarto_id = q.id
       JOIN propriedades p ON r.propriedade_id = p.id
       ORDER BY r.created_at DESC
       LIMIT ?`,
      [parseInt(limit)]
    );

    res.json({
      success: true,
      data: reservas
    });

  } catch (error) {
    console.error('Erro ao obter reservas recentes:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao carregar reservas recentes'
    });
  }
});

// Rota para obter ocupação por período
router.get('/ocupacao', async (req, res) => {
  try {
    const { dataInicio, dataFim } = req.query;
    
    if (!dataInicio || !dataFim) {
      return res.status(400).json({
        success: false,
        message: 'Data de início e fim são obrigatórias'
      });
    }

    const ocupacao = await query(
      `SELECT 
         DATE(data_checkin) as data,
         COUNT(*) as reservas,
         SUM(CASE WHEN status = 'checkin' THEN 1 ELSE 0 END) as ocupados
       FROM reservas 
       WHERE data_checkin BETWEEN ? AND ?
       AND status != 'cancelada'
       GROUP BY DATE(data_checkin)
       ORDER BY data_checkin`,
      [dataInicio, dataFim]
    );

    res.json({
      success: true,
      data: ocupacao
    });

  } catch (error) {
    console.error('Erro ao obter ocupação:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao carregar dados de ocupação'
    });
  }
});

// Rota para obter receita por período
router.get('/receita', async (req, res) => {
  try {
    const { dataInicio, dataFim } = req.query;
    
    if (!dataInicio || !dataFim) {
      return res.status(400).json({
        success: false,
        message: 'Data de início e fim são obrigatórias'
      });
    }

    const receita = await query(
      `SELECT 
         DATE(created_at) as data,
         SUM(valor_total) as receita_total,
         SUM(valor_pago) as receita_paga,
         COUNT(*) as total_reservas
       FROM reservas 
       WHERE created_at BETWEEN ? AND ?
       AND status != 'cancelada'
       GROUP BY DATE(created_at)
       ORDER BY created_at`,
      [dataInicio, dataFim]
    );

    res.json({
      success: true,
      data: receita
    });

  } catch (error) {
    console.error('Erro ao obter receita:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao carregar dados de receita'
    });
  }
});

module.exports = router;