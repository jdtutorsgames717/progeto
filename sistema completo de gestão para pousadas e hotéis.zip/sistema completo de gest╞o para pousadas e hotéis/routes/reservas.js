const express = require('express');
const { query } = require('../config/database');
const router = express.Router();

// Middleware de autenticação (copiado do auth.js)
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, message: 'Token de acesso requerido' });
  }

  const jwt = require('jsonwebtoken');
  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ success: false, message: 'Token inválido' });
    }
    req.user = user;
    next();
  });
};

// Aplicar middleware de autenticação
router.use(authenticateToken);

// Função para gerar código de reserva
function gerarCodigoReserva() {
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `RES${timestamp}${random}`;
}

// Listar todas as reservas
router.get('/', async (req, res) => {
  try {
    const { 
      page = 1, 
      limit = 20, 
      status, 
      dataInicio, 
      dataFim, 
      hospede, 
      propriedade 
    } = req.query;

    let whereClause = 'WHERE 1=1';
    let params = [];

    if (status) {
      whereClause += ' AND r.status = ?';
      params.push(status);
    }

    if (dataInicio) {
      whereClause += ' AND r.data_checkin >= ?';
      params.push(dataInicio);
    }

    if (dataFim) {
      whereClause += ' AND r.data_checkout <= ?';
      params.push(dataFim);
    }

    if (hospede) {
      whereClause += ' AND h.nome LIKE ?';
      params.push(`%${hospede}%`);
    }

    if (propriedade) {
      whereClause += ' AND r.propriedade_id = ?';
      params.push(propriedade);
    }

    const offset = (page - 1) * limit;
    params.push(parseInt(limit), offset);

    const reservas = await query(
      `SELECT r.*, h.nome as hospede_nome, h.email, h.telefone, h.documento,
              tq.nome as tipo_quarto, q.numero as quarto_numero,
              p.nome as propriedade_nome
       FROM reservas r
       JOIN hospedes h ON r.hospede_id = h.id
       JOIN tipos_quartos tq ON r.tipo_quarto_id = tq.id
       LEFT JOIN quartos q ON r.quarto_id = q.id
       JOIN propriedades p ON r.propriedade_id = p.id
       ${whereClause}
       ORDER BY r.created_at DESC
       LIMIT ? OFFSET ?`,
      params
    );

    // Contar total de registros
    const totalParams = params.slice(0, -2);
    const totalResult = await query(
      `SELECT COUNT(*) as total
       FROM reservas r
       JOIN hospedes h ON r.hospede_id = h.id
       JOIN tipos_quartos tq ON r.tipo_quarto_id = tq.id
       LEFT JOIN quartos q ON r.quarto_id = q.id
       JOIN propriedades p ON r.propriedade_id = p.id
       ${whereClause}`,
      totalParams
    );

    res.json({
      success: true,
      data: reservas,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: totalResult[0].total,
        pages: Math.ceil(totalResult[0].total / limit)
      }
    });

  } catch (error) {
    console.error('Erro ao listar reservas:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao carregar reservas'
    });
  }
});

// Obter reserva por ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const reservas = await query(
      `SELECT r.*, h.nome as hospede_nome, h.email, h.telefone, h.documento,
              h.data_nascimento, h.endereco, h.cidade, h.estado,
              tq.nome as tipo_quarto, tq.descricao as tipo_descricao,
              q.numero as quarto_numero, q.andar,
              p.nome as propriedade_nome, p.endereco as propriedade_endereco
       FROM reservas r
       JOIN hospedes h ON r.hospede_id = h.id
       JOIN tipos_quartos tq ON r.tipo_quarto_id = tq.id
       LEFT JOIN quartos q ON r.quarto_id = q.id
       JOIN propriedades p ON r.propriedade_id = p.id
       WHERE r.id = ?`,
      [id]
    );

    if (reservas.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Reserva não encontrada'
      });
    }

    // Buscar pagamentos da reserva
    const pagamentos = await query(
      'SELECT * FROM pagamentos WHERE reserva_id = ? ORDER BY created_at DESC',
      [id]
    );

    res.json({
      success: true,
      data: {
        ...reservas[0],
        pagamentos
      }
    });

  } catch (error) {
    console.error('Erro ao obter reserva:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao carregar reserva'
    });
  }
});

// Criar nova reserva
router.post('/', async (req, res) => {
  try {
    const {
      propriedade_id,
      hospede,
      tipo_quarto_id,
      quarto_id,
      data_checkin,
      data_checkout,
      adultos,
      criancas,
      valor_total,
      origem,
      observacoes
    } = req.body;

    // Validações básicas
    if (!propriedade_id || !hospede || !tipo_quarto_id || !data_checkin || !data_checkout || !valor_total) {
      return res.status(400).json({
        success: false,
        message: 'Campos obrigatórios não preenchidos'
      });
    }

    // Verificar se as datas são válidas
    if (new Date(data_checkin) >= new Date(data_checkout)) {
      return res.status(400).json({
        success: false,
        message: 'Data de check-out deve ser posterior ao check-in'
      });
    }

    // Verificar disponibilidade do quarto (se especificado)
    if (quarto_id) {
      const conflitos = await query(
        `SELECT id FROM reservas 
         WHERE quarto_id = ? 
         AND status NOT IN ('cancelada', 'checkout')
         AND (
           (data_checkin <= ? AND data_checkout > ?) OR
           (data_checkin < ? AND data_checkout >= ?) OR
           (data_checkin >= ? AND data_checkout <= ?)
         )`,
        [quarto_id, data_checkin, data_checkin, data_checkout, data_checkout, data_checkin, data_checkout]
      );

      if (conflitos.length > 0) {
        return res.status(400).json({
          success: false,
          message: 'Quarto não disponível para o período selecionado'
        });
      }
    }

    // Criar ou buscar hóspede
    let hospede_id;
    if (hospede.id) {
      hospede_id = hospede.id;
    } else {
      // Verificar se hóspede já existe pelo email ou documento
      const hospedeExistente = await query(
        'SELECT id FROM hospedes WHERE email = ? OR documento = ?',
        [hospede.email, hospede.documento]
      );

      if (hospedeExistente.length > 0) {
        hospede_id = hospedeExistente[0].id;
        // Atualizar dados do hóspede
        await query(
          `UPDATE hospedes SET 
           nome = ?, telefone = ?, data_nascimento = ?, 
           endereco = ?, cidade = ?, estado = ?, cep = ?
           WHERE id = ?`,
          [
            hospede.nome, hospede.telefone, hospede.data_nascimento,
            hospede.endereco, hospede.cidade, hospede.estado, hospede.cep,
            hospede_id
          ]
        );
      } else {
        // Criar novo hóspede
        const novoHospede = await query(
          `INSERT INTO hospedes 
           (nome, email, telefone, documento, tipo_documento, data_nascimento, 
            endereco, cidade, estado, cep, nacionalidade)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            hospede.nome, hospede.email, hospede.telefone, hospede.documento,
            hospede.tipo_documento || 'cpf', hospede.data_nascimento,
            hospede.endereco, hospede.cidade, hospede.estado, hospede.cep,
            hospede.nacionalidade || 'Brasileira'
          ]
        );
        hospede_id = novoHospede.insertId;
      }
    }

    // Gerar código da reserva
    const codigo_reserva = gerarCodigoReserva();

    // Criar reserva
    const novaReserva = await query(
      `INSERT INTO reservas 
       (propriedade_id, hospede_id, quarto_id, tipo_quarto_id, codigo_reserva,
        data_checkin, data_checkout, adultos, criancas, valor_total, origem, observacoes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        propriedade_id, hospede_id, quarto_id, tipo_quarto_id, codigo_reserva,
        data_checkin, data_checkout, adultos || 1, criancas || 0,
        valor_total, origem || 'direto', observacoes
      ]
    );

    // Atualizar status do quarto se especificado
    if (quarto_id && new Date(data_checkin) <= new Date()) {
      await query(
        'UPDATE quartos SET status = "ocupado" WHERE id = ?',
        [quarto_id]
      );
    }

    res.status(201).json({
      success: true,
      message: 'Reserva criada com sucesso',
      data: {
        id: novaReserva.insertId,
        codigo_reserva,
        hospede_id
      }
    });

  } catch (error) {
    console.error('Erro ao criar reserva:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao criar reserva'
    });
  }
});

// Atualizar reserva
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const {
      quarto_id,
      data_checkin,
      data_checkout,
      adultos,
      criancas,
      valor_total,
      status,
      observacoes
    } = req.body;

    // Verificar se reserva existe
    const reservaExistente = await query(
      'SELECT * FROM reservas WHERE id = ?',
      [id]
    );

    if (reservaExistente.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Reserva não encontrada'
      });
    }

    // Verificar conflitos de quarto se alterado
    if (quarto_id && quarto_id !== reservaExistente[0].quarto_id) {
      const conflitos = await query(
        `SELECT id FROM reservas 
         WHERE quarto_id = ? AND id != ?
         AND status NOT IN ('cancelada', 'checkout')
         AND (
           (data_checkin <= ? AND data_checkout > ?) OR
           (data_checkin < ? AND data_checkout >= ?) OR
           (data_checkin >= ? AND data_checkout <= ?)
         )`,
        [
          quarto_id, id,
          data_checkin || reservaExistente[0].data_checkin,
          data_checkin || reservaExistente[0].data_checkin,
          data_checkout || reservaExistente[0].data_checkout,
          data_checkout || reservaExistente[0].data_checkout,
          data_checkin || reservaExistente[0].data_checkin,
          data_checkout || reservaExistente[0].data_checkout
        ]
      );

      if (conflitos.length > 0) {
        return res.status(400).json({
          success: false,
          message: 'Quarto não disponível para o período selecionado'
        });
      }
    }

    // Atualizar reserva
    await query(
      `UPDATE reservas SET 
       quarto_id = COALESCE(?, quarto_id),
       data_checkin = COALESCE(?, data_checkin),
       data_checkout = COALESCE(?, data_checkout),
       adultos = COALESCE(?, adultos),
       criancas = COALESCE(?, criancas),
       valor_total = COALESCE(?, valor_total),
       status = COALESCE(?, status),
       observacoes = COALESCE(?, observacoes)
       WHERE id = ?`,
      [
        quarto_id, data_checkin, data_checkout, adultos, criancas,
        valor_total, status, observacoes, id
      ]
    );

    // Atualizar status do quarto se necessário
    if (status === 'checkin' && quarto_id) {
      await query(
        'UPDATE quartos SET status = "ocupado" WHERE id = ?',
        [quarto_id]
      );
    } else if (status === 'checkout' && reservaExistente[0].quarto_id) {
      await query(
        'UPDATE quartos SET status = "limpeza" WHERE id = ?',
        [reservaExistente[0].quarto_id]
      );
    }

    res.json({
      success: true,
      message: 'Reserva atualizada com sucesso'
    });

  } catch (error) {
    console.error('Erro ao atualizar reserva:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao atualizar reserva'
    });
  }
});

// Cancelar reserva
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { motivo } = req.body;

    // Verificar se reserva existe
    const reserva = await query(
      'SELECT * FROM reservas WHERE id = ?',
      [id]
    );

    if (reserva.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Reserva não encontrada'
      });
    }

    // Cancelar reserva
    await query(
      'UPDATE reservas SET status = "cancelada", observacoes = CONCAT(COALESCE(observacoes, ""), "\nCancelada: ", ?) WHERE id = ?',
      [motivo || 'Sem motivo informado', id]
    );

    // Liberar quarto se estava ocupado
    if (reserva[0].quarto_id) {
      await query(
        'UPDATE quartos SET status = "disponivel" WHERE id = ?',
        [reserva[0].quarto_id]
      );
    }

    res.json({
      success: true,
      message: 'Reserva cancelada com sucesso'
    });

  } catch (error) {
    console.error('Erro ao cancelar reserva:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao cancelar reserva'
    });
  }
});

module.exports = router;