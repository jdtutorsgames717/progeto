-- Criação do banco de dados
CREATE DATABASE IF NOT EXISTS hospedin_pms;
USE hospedin_pms;

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('admin', 'gerente', 'recepcionista', 'funcionario') DEFAULT 'funcionario',
    ativo BOOLEAN DEFAULT TRUE,
    ultimo_login DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de propriedades (hotéis/pousadas)
CREATE TABLE IF NOT EXISTS propriedades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    descricao TEXT,
    endereco TEXT,
    cidade VARCHAR(100),
    estado VARCHAR(50),
    cep VARCHAR(20),
    telefone VARCHAR(20),
    email VARCHAR(100),
    website VARCHAR(200),
    checkin_time TIME DEFAULT '14:00:00',
    checkout_time TIME DEFAULT '12:00:00',
    ativo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de tipos de quartos
CREATE TABLE IF NOT EXISTS tipos_quartos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    propriedade_id INT,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    capacidade_adultos INT DEFAULT 2,
    capacidade_criancas INT DEFAULT 0,
    preco_base DECIMAL(10,2) NOT NULL,
    area DECIMAL(5,2),
    comodidades JSON,
    ativo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (propriedade_id) REFERENCES propriedades(id)
);

-- Tabela de quartos
CREATE TABLE IF NOT EXISTS quartos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    propriedade_id INT,
    tipo_quarto_id INT,
    numero VARCHAR(20) NOT NULL,
    andar INT,
    status ENUM('disponivel', 'ocupado', 'manutencao', 'limpeza') DEFAULT 'disponivel',
    observacoes TEXT,
    ativo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (propriedade_id) REFERENCES propriedades(id),
    FOREIGN KEY (tipo_quarto_id) REFERENCES tipos_quartos(id),
    UNIQUE KEY unique_numero_propriedade (propriedade_id, numero)
);

-- Tabela de hóspedes
CREATE TABLE IF NOT EXISTS hospedes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    email VARCHAR(100),
    telefone VARCHAR(20),
    documento VARCHAR(50),
    tipo_documento ENUM('cpf', 'rg', 'passaporte', 'cnh') DEFAULT 'cpf',
    data_nascimento DATE,
    endereco TEXT,
    cidade VARCHAR(100),
    estado VARCHAR(50),
    cep VARCHAR(20),
    nacionalidade VARCHAR(50) DEFAULT 'Brasileira',
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de reservas
CREATE TABLE IF NOT EXISTS reservas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    propriedade_id INT,
    hospede_id INT,
    quarto_id INT,
    tipo_quarto_id INT,
    codigo_reserva VARCHAR(20) UNIQUE NOT NULL,
    data_checkin DATE NOT NULL,
    data_checkout DATE NOT NULL,
    adultos INT DEFAULT 1,
    criancas INT DEFAULT 0,
    valor_total DECIMAL(10,2) NOT NULL,
    valor_pago DECIMAL(10,2) DEFAULT 0,
    status ENUM('pendente', 'confirmada', 'checkin', 'checkout', 'cancelada', 'no_show') DEFAULT 'pendente',
    origem ENUM('direto', 'booking', 'airbnb', 'expedia', 'outros') DEFAULT 'direto',
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (propriedade_id) REFERENCES propriedades(id),
    FOREIGN KEY (hospede_id) REFERENCES hospedes(id),
    FOREIGN KEY (quarto_id) REFERENCES quartos(id),
    FOREIGN KEY (tipo_quarto_id) REFERENCES tipos_quartos(id)
);

-- Tabela de canais de distribuição
CREATE TABLE IF NOT EXISTS canais (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    tipo ENUM('ota', 'gds', 'direto', 'metasearch') DEFAULT 'ota',
    url VARCHAR(200),
    api_endpoint VARCHAR(200),
    api_key VARCHAR(255),
    comissao DECIMAL(5,2) DEFAULT 0,
    ativo BOOLEAN DEFAULT TRUE,
    configuracoes JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de inventário por canal
CREATE TABLE IF NOT EXISTS inventario_canais (
    id INT AUTO_INCREMENT PRIMARY KEY,
    propriedade_id INT,
    tipo_quarto_id INT,
    canal_id INT,
    data_disponibilidade DATE NOT NULL,
    quartos_disponiveis INT DEFAULT 0,
    preco DECIMAL(10,2) NOT NULL,
    restricoes JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (propriedade_id) REFERENCES propriedades(id),
    FOREIGN KEY (tipo_quarto_id) REFERENCES tipos_quartos(id),
    FOREIGN KEY (canal_id) REFERENCES canais(id),
    UNIQUE KEY unique_inventario (propriedade_id, tipo_quarto_id, canal_id, data_disponibilidade)
);

-- Tabela de tarifas
CREATE TABLE IF NOT EXISTS tarifas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    propriedade_id INT,
    tipo_quarto_id INT,
    nome VARCHAR(100) NOT NULL,
    data_inicio DATE NOT NULL,
    data_fim DATE NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    tipo ENUM('promocional', 'alta_temporada', 'baixa_temporada', 'especial') DEFAULT 'especial',
    ativo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (propriedade_id) REFERENCES propriedades(id),
    FOREIGN KEY (tipo_quarto_id) REFERENCES tipos_quartos(id)
);

-- Tabela de pagamentos
CREATE TABLE IF NOT EXISTS pagamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reserva_id INT,
    valor DECIMAL(10,2) NOT NULL,
    metodo ENUM('dinheiro', 'cartao_credito', 'cartao_debito', 'pix', 'transferencia', 'cheque') NOT NULL,
    status ENUM('pendente', 'aprovado', 'rejeitado', 'estornado') DEFAULT 'pendente',
    data_pagamento DATETIME,
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (reserva_id) REFERENCES reservas(id)
);

-- Inserir dados iniciais
INSERT INTO usuarios (nome, email, senha, tipo) VALUES 
('Administrador', 'admin@hospedin.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

INSERT INTO propriedades (nome, descricao, cidade, estado) VALUES 
('Hotel Exemplo', 'Hotel de exemplo para demonstração do sistema', 'São Paulo', 'SP');

INSERT INTO canais (nome, tipo, comissao) VALUES 
('Booking.com', 'ota', 15.00),
('Airbnb', 'ota', 12.00),
('Expedia', 'ota', 18.00),
('Direto', 'direto', 0.00);