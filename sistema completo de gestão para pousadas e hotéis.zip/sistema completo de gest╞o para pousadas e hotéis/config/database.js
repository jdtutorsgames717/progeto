const mysql = require('mysql2/promise');
require('dotenv').config();

// Configuração da conexão com o banco de dados
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'hospedin_pms',
  port: process.env.DB_PORT || 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  acquireTimeout: 60000,
  timeout: 60000,
  reconnect: true
};

// Criar pool de conexões
const pool = mysql.createPool(dbConfig);

// Função para testar conexão
async function testConnection() {
  try {
    const connection = await pool.getConnection();
    console.log('✅ Conexão com MySQL estabelecida com sucesso!');
    connection.release();
    return true;
  } catch (error) {
    console.error('❌ Erro ao conectar com MySQL:', error.message);
    return false;
  }
}

// Função para criar o banco de dados se não existir
async function createDatabase() {
  try {
    const tempConfig = { ...dbConfig };
    delete tempConfig.database;
    
    const tempPool = mysql.createPool(tempConfig);
    const connection = await tempPool.getConnection();
    
    await connection.execute(`CREATE DATABASE IF NOT EXISTS ${process.env.DB_NAME}`);
    console.log(`✅ Banco de dados '${process.env.DB_NAME}' criado/verificado com sucesso!`);
    
    connection.release();
    await tempPool.end();
    return true;
  } catch (error) {
    console.error('❌ Erro ao criar banco de dados:', error.message);
    return false;
  }
}

// Função para executar queries
async function query(sql, params = []) {
  try {
    const [results] = await pool.execute(sql, params);
    return results;
  } catch (error) {
    console.error('❌ Erro na query:', error.message);
    throw error;
  }
}

// Função para inicializar o banco
async function initializeDatabase() {
  try {
    await createDatabase();
    await testConnection();
    console.log('🗄️ Sistema de banco de dados inicializado!');
  } catch (error) {
    console.error('❌ Erro ao inicializar banco de dados:', error.message);
    process.exit(1);
  }
}

module.exports = {
  pool,
  query,
  testConnection,
  createDatabase,
  initializeDatabase
};